<?php

namespace ContainerNUZhZvW;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder3ed7a = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializercc0ca = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties415ec = [
        
    ];

    public function getConnection()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getConnection', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getMetadataFactory', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getExpressionBuilder', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'beginTransaction', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->beginTransaction();
    }

    public function getCache()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getCache', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getCache();
    }

    public function transactional($func)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'transactional', array('func' => $func), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->transactional($func);
    }

    public function commit()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'commit', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->commit();
    }

    public function rollback()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'rollback', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getClassMetadata', array('className' => $className), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'createQuery', array('dql' => $dql), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'createNamedQuery', array('name' => $name), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'createQueryBuilder', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'flush', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'clear', array('entityName' => $entityName), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->clear($entityName);
    }

    public function close()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'close', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->close();
    }

    public function persist($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'persist', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'remove', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'refresh', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'detach', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'merge', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getRepository', array('entityName' => $entityName), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'contains', array('entity' => $entity), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getEventManager', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getConfiguration', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'isOpen', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getUnitOfWork', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getProxyFactory', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'initializeObject', array('obj' => $obj), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'getFilters', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'isFiltersStateClean', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'hasFilters', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return $this->valueHolder3ed7a->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializercc0ca = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder3ed7a) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder3ed7a = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder3ed7a->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__get', ['name' => $name], $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        if (isset(self::$publicProperties415ec[$name])) {
            return $this->valueHolder3ed7a->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3ed7a;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder3ed7a;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__set', array('name' => $name, 'value' => $value), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3ed7a;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder3ed7a;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__isset', array('name' => $name), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3ed7a;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder3ed7a;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__unset', array('name' => $name), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3ed7a;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder3ed7a;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__clone', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        $this->valueHolder3ed7a = clone $this->valueHolder3ed7a;
    }

    public function __sleep()
    {
        $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, '__sleep', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;

        return array('valueHolder3ed7a');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializercc0ca = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializercc0ca;
    }

    public function initializeProxy() : bool
    {
        return $this->initializercc0ca && ($this->initializercc0ca->__invoke($valueHolder3ed7a, $this, 'initializeProxy', array(), $this->initializercc0ca) || 1) && $this->valueHolder3ed7a = $valueHolder3ed7a;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder3ed7a;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder3ed7a;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
